
# App Showcase (Next.js)

## التشغيل

```bash
npm install
npm run dev
```

## إضافة تطبيق جديد

افتح الملف:

data/appsData.js

وأضف تطبيقاً جديداً داخل المصفوفة.
