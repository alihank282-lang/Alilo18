
export const apps = [
  {
    id: "quran-app",
    name: "تطبيق القرآن الكريم",
    category: "إسلامية",
    icon: "https://via.placeholder.com/128",
    description: "تطبيق شامل لقراءة القرآن الكريم مع التفسير.",
    fullDescription: "هذا التطبيق يوفر تجربة مميزة لقراءة القرآن الكريم مع ميزات متقدمة مثل البحث والتفسير والاستماع.",
    screenshots: [
      "https://via.placeholder.com/600x400",
      "https://via.placeholder.com/600x400"
    ],
    downloadUrl: "https://example.com/download"
  },
  {
    id: "notes-app",
    name: "تطبيق الملاحظات",
    category: "إنتاجية",
    icon: "https://via.placeholder.com/128",
    description: "دوّن ملاحظاتك بسهولة وسرعة.",
    fullDescription: "تطبيق ملاحظات سريع وخفيف يساعدك على تنظيم أفكارك ومهامك اليومية.",
    screenshots: [
      "https://via.placeholder.com/600x400",
      "https://via.placeholder.com/600x400"
    ],
    downloadUrl: "https://example.com/download"
  }
];
