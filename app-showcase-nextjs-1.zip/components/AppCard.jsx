
import Link from 'next/link';

export default function AppCard({ app }) {
  return (
    <Link href={`/app/${app.id}`}>
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow hover:shadow-lg transition p-4 cursor-pointer">
        <img src={app.icon} alt={app.name} className="w-16 h-16 rounded-xl mb-3" />
        <h3 className="font-bold mb-1">{app.name}</h3>
        <p className="text-sm text-gray-500">{app.description}</p>
      </div>
    </Link>
  );
}
