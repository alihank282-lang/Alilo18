
export default function Footer() {
  return (
    <footer className="border-t mt-10 py-6 text-center text-sm text-gray-500 dark:border-gray-800">
      © {new Date().getFullYear()} جميع الحقوق محفوظة
    </footer>
  );
}
