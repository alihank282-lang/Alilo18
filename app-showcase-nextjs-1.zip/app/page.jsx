
'use client';

import { useState } from 'react';
import { apps } from '@/data/appsData';
import AppCard from '@/components/AppCard';

export default function HomePage() {
  const categories = ['الكل', ...new Set(apps.map(a => a.category))];
  const [active, setActive] = useState('الكل');

  const filtered =
    active === 'الكل' ? apps : apps.filter(a => a.category === active);

  return (
    <div>
      <section className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-3">🚀 أفضل تطبيقاتي</h1>
        <p className="text-gray-500">اكتشف وحمّل أحدث التطبيقات بسهولة</p>
      </section>

      <div className="flex gap-2 flex-wrap justify-center mb-6">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActive(cat)}
            className={`px-4 py-2 rounded-full border ${
              active === cat ? 'bg-black text-white dark:bg-white dark:text-black' : ''
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filtered.map(app => (
          <AppCard key={app.id} app={app} />
        ))}
      </div>
    </div>
  );
}
