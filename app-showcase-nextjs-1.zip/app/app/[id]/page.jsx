
import { apps } from '@/data/appsData';
import { notFound } from 'next/navigation';

export default function AppDetails({ params }) {
  const app = apps.find(a => a.id === params.id);
  if (!app) return notFound();

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <img src={app.icon} className="w-24 h-24 rounded-2xl" />
        <div>
          <h1 className="text-3xl font-bold">{app.name}</h1>
          <p className="text-gray-500">{app.category}</p>
        </div>
      </div>

      <p className="mb-6 leading-relaxed">{app.fullDescription}</p>

      <div className="grid md:grid-cols-2 gap-4 mb-8">
        {app.screenshots.map((s, i) => (
          <img key={i} src={s} className="rounded-xl shadow" />
        ))}
      </div>

      <a
        href={app.downloadUrl}
        target="_blank"
        className="inline-block bg-green-600 text-white px-6 py-3 rounded-xl font-bold"
      >
        ⬇️ تحميل التطبيق
      </a>
    </div>
  );
}
